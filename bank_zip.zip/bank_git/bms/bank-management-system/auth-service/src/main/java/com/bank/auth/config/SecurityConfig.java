// This file has been removed - Spring Security is no longer used
