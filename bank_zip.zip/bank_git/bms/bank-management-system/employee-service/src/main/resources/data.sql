-- Insert demo employee records
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('John', 'Doe', 'john.doe@bank.com', '1234567890', 'Clerk', 25000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('Jane', 'Smith', 'jane.smith@bank.com', '1234567891', 'Manager', 75000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('Mike', 'Johnson', 'mike.johnson@bank.com', '1234567892', 'Accountant', 50000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('Sarah', 'Williams', 'sarah.williams@bank.com', '1234567893', 'Clerk', 26000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('David', 'Brown', 'david.brown@bank.com', '1234567894', 'Manager', 80000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('Lisa', 'Davis', 'lisa.davis@bank.com', '1234567895', 'Clerk', 24000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('Robert', 'Miller', 'robert.miller@bank.com', '1234567896', 'Accountant', 52000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('Emily', 'Wilson', 'emily.wilson@bank.com', '1234567897', 'Manager', 78000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('James', 'Moore', 'james.moore@bank.com', '1234567898', 'Clerk', 27000.00);
INSERT INTO employees (first_name, last_name, email, contact_number, designation, salary) VALUES ('Amanda', 'Taylor', 'amanda.taylor@bank.com', '1234567899', 'Accountant', 48000.00);
