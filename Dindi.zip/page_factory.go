page_factory.go
package risaweb

import (
	"fmt"
	"github.com/maxence-charriere/go-app/v10/pkg/app"
	"oxford.awsdev.infor.com/zgo/zcomponents/pkg/zcomponents"
	"oxford.awsdev.infor.com/zgo/zlog/logger"
	"regexp"
	"strings"
)

const (
	MenuIdResources            = zcomponents.MenuId("resources")
	MenuIdHome                 = zcomponents.MenuId("home")
	MenuIdEksClusters          = zcomponents.MenuId("eksClusters")
	MenuIdEc2Instances         = zcomponents.MenuId("ec2Instances")
	MenuIdCFStacks             = zcomponents.MenuId("cfStacks")
	MenuIdDynamoDbTables       = zcomponents.MenuId("dynamoDbTables")
	MenuIdEC2Images            = zcomponents.MenuId("ec2Images")
	MenuIdClassicLoadBalancers = zcomponents.MenuId("classicLoadBalancers")
	MenuIdRDSSnapshots         = zcomponents.MenuId("rdssnapshots")
	MenuIdElasticIpAddress     = zcomponents.MenuId("elasticIpAddress")
	MenuIdTargetGroups         = zcomponents.MenuId("targetGroups")
	MenuIdNATGateway           = zcomponents.MenuId("natGateways")
	MenuIdVolumes              = zcomponents.MenuId("volumes")
	MenuIdSnapshots            = zcomponents.MenuId("snapshots")
	MenuIdHelp                 = zcomponents.MenuId("help")
	MenuIdS3Buckets            = zcomponents.MenuId("s3Buckets")
	MenuIdRDSDatabases         = zcomponents.MenuId("rdsDatabases")
	MenuIdLambdaFunctions      = zcomponents.MenuId("lambdaFunctions")
	MenuIdVPCs                 = zcomponents.MenuId("vpcs")
)

// RoutePattern represents a pattern used for routing in a web application.
type RoutePattern struct {
	Pattern    string
	Regex      *regexp.Regexp
	ParamNames []string // Names of parameters in order
	Component  func(params map[string]string) (zcomponents.PageInterface, error)
}

// PageFactory is a component that manages the navigation between pages in a web application.
// It handles page creation, navigation, and layout management.
// It also provides a simple way to create and manage page components.
//
// The PageFactory component is responsible for:
// - Creating and managing page components
// - Managing page navigation
// - Managing page layouts
type PageFactory struct {
	app.Compo
	layout *zcomponents.MainLayout

	currentPage            zcomponents.PageInterface
	currentPageID          string
	currentPagePath        string
	hasError               bool
	pageCache              map[string]zcomponents.PageInterface
	globalSidebarCollapsed bool
	resourcesMenuExpanded  bool
	computeMenuExpanded    bool
	storageMenuExpanded    bool
	databaseMenuExpanded   bool
	networkingMenuExpanded bool
	managementMenuExpanded bool
	done                   chan bool
	sidebarCollapsed       bool
}

// isSidebarCollapsed returns the current state of the sidebarCollapsed field.
func (p *PageFactory) isSidebarCollapsed() bool {
	return p.sidebarCollapsed
}

// menuTitle returns the menu title based on sidebar collapsed state
func (p *PageFactory) menuTitle(icon, label string) string {
	if p.isSidebarCollapsed() {
		return icon
	}
	return label
}

// New category menu state methods
func (p *PageFactory) isComputeMenuExpanded() bool {
	return p.computeMenuExpanded
}

// toggleComputeMenu toggles the compute menu's expanded state and logs the change.
func (p *PageFactory) toggleComputeMenu(ctx app.Context) {
	oldState := p.computeMenuExpanded
	p.computeMenuExpanded = !p.computeMenuExpanded
	logger.Infof("🔄 TOGGLE: Compute menu toggled from %v to %v", oldState, p.computeMenuExpanded)

	// Refresh the menu structure by updating the layout with new menu items
	if p.layout != nil {
		newMenuItems := p.getDefaultMenuItems()
		logger.Infof("🔄 TOGGLE: Generated %d menu items for compute %s state", len(newMenuItems),
			map[bool]string{true: "expanded", false: "collapsed"}[p.computeMenuExpanded])

		p.layout.SetMenuItems(newMenuItems)
		logger.Infof("🔄 TOGGLE: Menu items updated in layout (compute)")

		// Update active menu item to maintain highlighting
		if p.currentPage != nil {
			activeTitle := p.getTreeMenuTitle(p.currentPage.GetPageTitle())
			logger.Infof("🔄 TOGGLE: Setting active menu item to: '%s' (compute)", activeTitle)
			zcomponents.UpdateActiveMenuItem(p.layout, activeTitle)
		}

		// Force a re-render to update the menu state immediately
		ctx.Update()
		logger.Infof("🔄 TOGGLE: Context updated - compute toggle should be visible now")

		ctx.Async(func() {
			logger.Infof("🔄 TOGGLE: Compute menu toggle completed, final state is: %v", p.computeMenuExpanded)
		})
	} else {
		logger.Warnf("🔄 TOGGLE: Layout is nil - cannot update compute menu items")
	}
}

// isStorageMenuExpanded returns true if the storage menu is expanded.
func (p *PageFactory) isStorageMenuExpanded() bool {
	return p.storageMenuExpanded
}

// toggleStorageMenu toggles the storage menu's expanded state and logs the change.
func (p *PageFactory) toggleStorageMenu(ctx app.Context) {
	oldState := p.storageMenuExpanded
	p.storageMenuExpanded = !p.storageMenuExpanded
	logger.Infof("🔄 TOGGLE: Storage menu toggled from %v to %v", oldState, p.storageMenuExpanded)

	// toggleStorageMenu updates layout and context after toggling the storage menu state.
	if p.layout != nil {
		newMenuItems := p.getDefaultMenuItems()
		logger.Infof("🔄 TOGGLE: Generated %d menu items for storage %s state", len(newMenuItems),
			map[bool]string{true: "expanded", false: "collapsed"}[p.storageMenuExpanded])

		p.layout.SetMenuItems(newMenuItems)
		logger.Infof("🔄 TOGGLE: Menu items updated in layout (storage)")

		if p.currentPage != nil {
			activeTitle := p.getTreeMenuTitle(p.currentPage.GetPageTitle())
			logger.Infof("🔄 TOGGLE: Setting active menu item to: '%s' (storage)", activeTitle)
			zcomponents.UpdateActiveMenuItem(p.layout, activeTitle)
		}

		ctx.Update()
		logger.Infof("🔄 TOGGLE: Context updated - storage toggle should be visible now")

		ctx.Async(func() {
			logger.Infof("🔄 TOGGLE: Storage menu toggle completed, final state is: %v", p.storageMenuExpanded)
		})
	} else {
		logger.Warnf("🔄 TOGGLE: Layout is nil - cannot update storage menu items")
	}
}

// isDatabaseMenuExpanded returns true if the database menu is expanded.
func (p *PageFactory) isDatabaseMenuExpanded() bool {
	return p.databaseMenuExpanded
}

// toggleDatabaseMenu toggles the database menu's expanded state and logs the change.
func (p *PageFactory) toggleDatabaseMenu(ctx app.Context) {
	oldState := p.databaseMenuExpanded
	p.databaseMenuExpanded = !p.databaseMenuExpanded
	logger.Infof("🔄 TOGGLE: Database menu toggled from %v to %v", oldState, p.databaseMenuExpanded)

	// toggleDatabaseMenu updates layout and context after toggling the database menu state.
	if p.layout != nil {
		newMenuItems := p.getDefaultMenuItems()
		logger.Infof("🔄 TOGGLE: Generated %d menu items for database %s state", len(newMenuItems),
			map[bool]string{true: "expanded", false: "collapsed"}[p.databaseMenuExpanded])

		p.layout.SetMenuItems(newMenuItems)
		logger.Infof("🔄 TOGGLE: Menu items updated in layout (database)")

		if p.currentPage != nil {
			activeTitle := p.getTreeMenuTitle(p.currentPage.GetPageTitle())
			logger.Infof("🔄 TOGGLE: Setting active menu item to: '%s' (database)", activeTitle)
			zcomponents.UpdateActiveMenuItem(p.layout, activeTitle)
		}

		ctx.Update()
		logger.Infof("🔄 TOGGLE: Context updated - database toggle should be visible now")

		ctx.Async(func() {
			logger.Infof("🔄 TOGGLE: Database menu toggle completed, final state is: %v", p.databaseMenuExpanded)
		})
	} else {
		logger.Warnf("🔄 TOGGLE: Layout is nil - cannot update database menu items")
	}
}

// isNetworkingMenuExpanded returns true if the networking menu is expanded.
func (p *PageFactory) isNetworkingMenuExpanded() bool {
	return p.networkingMenuExpanded
}

// toggleNetworkingMenu toggles the networking menu's expanded state and logs the change.
func (p *PageFactory) toggleNetworkingMenu(ctx app.Context) {
	oldState := p.networkingMenuExpanded
	p.networkingMenuExpanded = !p.networkingMenuExpanded
	logger.Infof("🔄 TOGGLE: Networking menu toggled from %v to %v", oldState, p.networkingMenuExpanded)

	// toggleNetworkingMenu updates layout and context after toggling the networking menu state.
	if p.layout != nil {
		newMenuItems := p.getDefaultMenuItems()
		logger.Infof("🔄 TOGGLE: Generated %d menu items for networking %s state", len(newMenuItems),
			map[bool]string{true: "expanded", false: "collapsed"}[p.networkingMenuExpanded])

		p.layout.SetMenuItems(newMenuItems)
		logger.Infof("🔄 TOGGLE: Menu items updated in layout (networking)")

		if p.currentPage != nil {
			activeTitle := p.getTreeMenuTitle(p.currentPage.GetPageTitle())
			logger.Infof("🔄 TOGGLE: Setting active menu item to: '%s' (networking)", activeTitle)
			zcomponents.UpdateActiveMenuItem(p.layout, activeTitle)
		}

		ctx.Update()
		logger.Infof("🔄 TOGGLE: Context updated - networking toggle should be visible now")

		ctx.Async(func() {
			logger.Infof("🔄 TOGGLE: Networking menu toggle completed, final state is: %v", p.networkingMenuExpanded)
		})
	} else {
		logger.Warnf("🔄 TOGGLE: Layout is nil - cannot update networking menu items")
	}
}

// isManagementMenuExpanded returns true if the management menu is expanded.
func (p *PageFactory) isManagementMenuExpanded() bool {
	return p.managementMenuExpanded
}

// toggleManagementMenu toggles the management menu's expanded state and logs the change.
func (p *PageFactory) toggleManagementMenu(ctx app.Context) {
	oldState := p.managementMenuExpanded
	p.managementMenuExpanded = !p.managementMenuExpanded
	logger.Infof("🔄 TOGGLE: Management menu toggled from %v to %v", oldState, p.managementMenuExpanded)

	// toggleManagementMenu updates layout and context after toggling the management menu state.
	if p.layout != nil {
		newMenuItems := p.getDefaultMenuItems()
		logger.Infof("🔄 TOGGLE: Generated %d menu items for management %s state", len(newMenuItems),
			map[bool]string{true: "expanded", false: "collapsed"}[p.managementMenuExpanded])

		p.layout.SetMenuItems(newMenuItems)
		logger.Infof("🔄 TOGGLE: Menu items updated in layout (management)")

		if p.currentPage != nil {
			activeTitle := p.getTreeMenuTitle(p.currentPage.GetPageTitle())
			logger.Infof("🔄 TOGGLE: Setting active menu item to: '%s' (management)", activeTitle)
			zcomponents.UpdateActiveMenuItem(p.layout, activeTitle)
		}

		ctx.Update()
		logger.Infof("🔄 TOGGLE: Context updated - management toggle should be visible now")

		ctx.Async(func() {
			logger.Infof("🔄 TOGGLE: Management menu toggle completed, final state is: %v", p.managementMenuExpanded)
		})
	} else {
		logger.Warnf("🔄 TOGGLE: Layout is nil - cannot update management menu items")
	}
}

// toggleResourcesMenu manually toggles the Resources menu expansion state
func (p *PageFactory) toggleResourcesMenu(ctx app.Context) {
	oldState := p.resourcesMenuExpanded
	p.resourcesMenuExpanded = !p.resourcesMenuExpanded
	logger.Infof("🔄 TOGGLE: Resources menu toggled from %v to %v", oldState, p.resourcesMenuExpanded)

	// Refresh the menu structure by updating the layout with new menu items
	if p.layout != nil {
		// Update the menu items in the layout
		newMenuItems := p.getDefaultMenuItems()
		logger.Infof("🔄 TOGGLE: Generated %d menu items for %s state", len(newMenuItems),
			map[bool]string{true: "expanded", false: "collapsed"}[p.resourcesMenuExpanded])

		p.layout.SetMenuItems(newMenuItems)
		logger.Infof("🔄 TOGGLE: Menu items updated in layout")

		// Update the active menu item to maintain highlighting with correct tree format
		if p.currentPage != nil {
			activeTitle := p.getTreeMenuTitle(p.currentPage.GetPageTitle())
			logger.Infof("🔄 TOGGLE: Setting active menu item to: '%s'", activeTitle)
			zcomponents.UpdateActiveMenuItem(p.layout, activeTitle)
		}

		// Force a re-render to update the menu state immediately
		ctx.Update()
		logger.Infof("🔄 TOGGLE: Context updated - toggle should be visible now")

		// Add a small delay to ensure the menu update is processed before navigation
		ctx.Async(func() {
			logger.Infof("🔄 TOGGLE: Menu toggle completed, final state is: %v", p.resourcesMenuExpanded)
		})
	} else {
		logger.Warnf("🔄 TOGGLE: Layout is nil - cannot update menu items")
	}
}

// getIconForPageTitle returns the appropriate icon for a page title
func (p *PageFactory) getIconForPageTitle(title string) string {
	iconMap := map[string]string{
		"Resources":             "🏗️",
		"EKS Clusters":          "⚙️",
		"EC2 Instances":         "☁️",
		"CloudFormation Stacks": "📚",
		"DynamoDB Tables":       "📚",
		"EC2 Images":            "💿",
		"Classic LoadBalancers": "⚖️",
		"RDS Snapshots":         "🗄️",
		"Elastic IP Address":    "🌍",
		"Target Groups":         "🎯",
		"NAT Gateway":           "🚪",
		"Volumes":               "💽",
		"Snapshots":             "📸",
	}

	if icon, exists := iconMap[title]; exists {
		return icon
	}
	return ""
}

// isResourcesMenuExpanded returns whether the Resources menu should be expanded
func (p *PageFactory) isResourcesMenuExpanded() bool {
	// Always respect the manual toggle state - users should be able to collapse even on AWS service pages
	return p.resourcesMenuExpanded
}

// getDefaultMenuItems returns the standard menu items using a tree structure with visual indicators
func (p *PageFactory) getDefaultMenuItems() []zcomponents.MenuItem {
	menuItems := []zcomponents.MenuItem{}
	isExpanded := p.isResourcesMenuExpanded()
	currentPageTitle := ""
	if p.currentPage != nil {
		currentPageTitle = p.currentPage.GetPageTitle()
	}

	logger.Infof("Building menu items - Resources expanded: %v (manual state: %v) for page: '%s'",
		isExpanded, p.resourcesMenuExpanded, currentPageTitle)

	homeItem := zcomponents.MenuItem{
		ID:     MenuIdHome,
		Title:  "🏠 Home",
		Icon:   "🏠",
		Active: currentPageTitle == "Home",
		URL:    "/",
		OnClick: func(ctx app.Context, e app.Event) {
			e.PreventDefault()
			ctx.Navigate("/")
		},
	}

	menuItems = append(menuItems, homeItem)

	resourcesItem := zcomponents.MenuItem{
		ID:     MenuIdResources,
		Title:  "🏗️Resources",
		Icon:   "🏗️",
		Active: p.currentPage != nil && p.currentPage.GetPageTitle() == "Resources",
		URL:    "",
		OnClick: func(ctx app.Context, e app.Event) {
			logger.Infof("🔘 CLICK: Resources menu clicked - starting toggle and navigation process")
			e.PreventDefault()
			p.toggleResourcesMenu(ctx)
			ctx.Async(func() {
				logger.Infof("🔘 CLICK: Starting delayed navigation to Resources dashboard")
				ctx.Navigate("/")
				logger.Infof("🔘 CLICK: Navigation to / completed")
			})
		},
	}
	menuItems = append(menuItems, resourcesItem)

	// Helper to build category sections
	buildCategory := func(id zcomponents.MenuId, iconEmoji string, label string, expanded bool, toggleFunc func(ctx app.Context), children []zcomponents.MenuItem) {
		menuItems = append(menuItems, zcomponents.MenuItem{
			ID:    zcomponents.MenuId(string(id) + "-expandable"),
			Title: label, // expanded → only text with arrow
			Icon:  iconEmoji,
			URL:   "",
			OnClick: func(ctx app.Context, e app.Event) {
				logger.Infof("🔘 CLICK: %s category clicked - toggling", label)
				e.PreventDefault()
				toggleFunc(ctx)
			},
		})
		if expanded {
			menuItems = append(menuItems, children...)
		}
	}

	if isExpanded {
		logger.Infof("Adding grouped AWS-style child menu items - Resources menu is expanded")

		// --- Compute ---
		buildCategory(
			zcomponents.MenuId("compute-category"),
			"💻", "💻Compute",
			p.isComputeMenuExpanded(),
			p.toggleComputeMenu,
			[]zcomponents.MenuItem{
				{ID: MenuIdEc2Instances, Title: p.menuTitle("☁️", " EC2 Instances"), Icon: "☁️", Active: currentPageTitle == " EC2 Instances", URL: "/ec2-instances"},
				{ID: MenuIdEC2Images, Title: p.menuTitle("💿", " EC2 Images"), Icon: "💿", Active: currentPageTitle == " EC2 Images", URL: "/ec2-images"},
				{ID: MenuIdEksClusters, Title: p.menuTitle("⚙️", " EKS Clusters"), Icon: "⚙️", Active: currentPageTitle == " EKS Clusters", URL: "/eks-clusters"},
				{ID: MenuIdLambdaFunctions, Title: p.menuTitle("🔧", " Lambda Functions"), Icon: "🔧", Active: currentPageTitle == " Lambda Functions", URL: "/lambda-functions"},
			},
		)

		// --- Storage ---
		buildCategory(
			zcomponents.MenuId("storage-category"),
			"💽", "💽Storage",
			p.isStorageMenuExpanded(),
			p.toggleStorageMenu,
			[]zcomponents.MenuItem{
				{ID: MenuIdVolumes, Title: p.menuTitle("💽", " Volumes"), Icon: "💽", Active: currentPageTitle == " Volumes", URL: "/volumes"},
				{ID: MenuIdSnapshots, Title: p.menuTitle("📸", " Snapshots"), Icon: "📸", Active: currentPageTitle == "  Snapshots", URL: "/snapshots"},
				{ID: MenuIdS3Buckets, Title: p.menuTitle("🪣", " S3 Buckets"), Icon: "🪣", Active: currentPageTitle == " S3 Buckets", URL: "/s3-buckets"},
			},
		)

		// --- Database ---
		buildCategory(
			zcomponents.MenuId("database-category"),
			"🛢️", "🛢️Database",
			p.isDatabaseMenuExpanded(),
			p.toggleDatabaseMenu,
			[]zcomponents.MenuItem{
				{ID: MenuIdDynamoDbTables, Title: p.menuTitle("📚", " DynamoDB Tables"), Icon: "📚", Active: currentPageTitle == " DynamoDB Tables", URL: "/dynamodb-tables"},
				{ID: MenuIdRDSSnapshots, Title: p.menuTitle("🗄️", " RDS Snapshots"), Icon: "🗄️", Active: currentPageTitle == " RDS Snapshots", URL: "/rds-snapshots"},
				{ID: MenuIdRDSDatabases, Title: p.menuTitle("🛢️", " RDS Databases"), Icon: "🛢️", Active: currentPageTitle == " RDS Databases", URL: "/rds-databases"},
			},
		)

		// --- Networking & Content Delivery ---
		buildCategory(
			zcomponents.MenuId("networking-category"),
			"🌐", "🌐Networking & Content Delivery",
			p.isNetworkingMenuExpanded(),
			p.toggleNetworkingMenu,
			[]zcomponents.MenuItem{
				{ID: MenuIdElasticIpAddress, Title: p.menuTitle("🌍", " Elastic IP Address"), Icon: "🌍", Active: currentPageTitle == " Elastic IP Address", URL: "/elastic-ips"},
				{ID: MenuIdNATGateway, Title: p.menuTitle("🚪", " NAT Gateway"), Icon: "🚪", Active: currentPageTitle == " NAT Gateway", URL: "/nat-gateways"},
				{ID: MenuIdClassicLoadBalancers, Title: p.menuTitle("⚖️", " Classic LoadBalancers"), Icon: "⚖️", Active: currentPageTitle == " Classic LoadBalancers", URL: "/elb-data"},
				{ID: MenuIdTargetGroups, Title: p.menuTitle("🎯", " Target Groups"), Icon: "🎯", Active: currentPageTitle == " Target Groups", URL: "/target-groups"},
				{ID: MenuIdVPCs, Title: p.menuTitle("🌐", " VPC"), Icon: "🌐", Active: currentPageTitle == " VPC", URL: "/vpc"},
			},
		)

		// --- Management & Governance ---
		buildCategory(
			zcomponents.MenuId("management-category"),
			"📊", "📊 Management & Governance",
			p.isManagementMenuExpanded(),
			p.toggleManagementMenu,
			[]zcomponents.MenuItem{
				{ID: MenuIdCFStacks, Title: p.menuTitle("📚", " CloudFormation Stacks"), Icon: "📚", Active: currentPageTitle == " CloudFormation Stacks", URL: "/cf-stacks"},
			},
		)
		logger.Infof("Added %d grouped child items to menu", len(menuItems)-1)
	} else {
		logger.Infof("Skipping child menu items - Resources menu is collapsed")
	}

	// --- Help ---
	menuItems = append(menuItems, zcomponents.MenuItem{
		ID:     MenuIdHelp,
		Title:  "❓Help",
		Icon:   "❓",
		Active: p.currentPage != nil && p.currentPage.GetPageTitle() == "Help",
		URL:    "/help",
	})

	logger.Infof("Final menu has %d total items", len(menuItems))
	return menuItems
}

// getAppUserProfile returns the user profile for the person management app
func (p *PageFactory) getAppUserProfile() zcomponents.UserProfile {
	return zcomponents.UserProfile{
		Name:   "user",
		Avatar: "",
		Email:  "admin@example.com",
		OnClick: func(ctx app.Context, e app.Event) {
			logger.Infof("User profile clicked")
		},
	}
}

// getPageRoutes returns all available routes
// define all the routes with URL pattern in regex
func (p *PageFactory) getPageRoutes() []RoutePattern {
	routes := []RoutePattern{
		{
			Pattern: "/",
			Component: func(params map[string]string) (zcomponents.PageInterface, error) {
				return NewHomePage(), nil
			},
		},
		{
			Pattern: "/eks-clusters",
			Component: func(params map[string]string) (zcomponents.PageInterface, error) {
				return NewEksPage(), nil
			},
		},
		{
			Pattern: "/ec2-instances",
			Component: func(params map[string]string) (zcomponents.PageInterface, error) {
				return NewEc2InstancePage(), nil
			},
		},
	}
	return routes
}

// extractParams extracts parameters from regex matches using parameter names
func (p *PageFactory) extractParams(route RoutePattern, matches []string) map[string]string {
	params := make(map[string]string)

	// matches[0] is the full match, `matches[1:]` are the captured groups
	for i, paramName := range route.ParamNames {
		if i+1 < len(matches) {
			params[paramName] = matches[i+1]
		}
	}

	return params
}

// getPage resolves the given path to a corresponding page component and returns it or a default page on failure.
func (p *PageFactory) getPage(path string) (zcomponents.PageInterface, error) {
	normalizedPath := p.normalizePath(path)
	logger.Infof("getPage called with path: '%s', normalized: '%s'", path, normalizedPath)

	// Check cache first
	if cachedPage, exists := p.pageCache[normalizedPath]; exists {
		logger.Debugf("returning cached page for path: %s", normalizedPath)
		return cachedPage, nil
	}

	// get all available routes
	routes := p.getPageRoutes()
	logger.Infof("Checking %d routes for path: %s", len(routes), normalizedPath)

	// check if the path matches any of the routes
	for i, route := range routes {
		logger.Infof("Route %d: Pattern='%s', Regex=%v", i, route.Pattern, route.Regex != nil)
		if route.Regex != nil {
			if route.Regex.MatchString(normalizedPath) {
				params := p.extractParams(route, route.Regex.FindStringSubmatch(normalizedPath))
				page, err := route.Component(params)
				if err == nil {
					// Cache the page for reuse (note: parameterized routes might need special handling)
					p.pageCache[normalizedPath] = page
					logger.Debugf("cached new page for path: %s", normalizedPath)
				}
				logger.Infof("Matched regex route %d for path: %s", i, normalizedPath)
				return page, err
			}
		} else if route.Pattern == normalizedPath {
			logger.Infof("Matched string route %d: '%s' == '%s'", i, route.Pattern, normalizedPath)
			page, err := route.Component(nil)
			if err == nil {
				// Cache the page for reuse
				p.pageCache[normalizedPath] = page
				logger.Debugf("cached new page for path: %s", normalizedPath)
			}
			return page, err
		} else {
			logger.Infof("Route %d no match: '%s' != '%s'", i, route.Pattern, normalizedPath)
		}
	}

	logger.Infof("No route matched for path: %s, using default", normalizedPath)
	// Default fallback
	defaultPath := "/"
	if cachedPage, exists := p.pageCache[defaultPath]; exists {
		return cachedPage, nil
	}

	page := NewHomePage()
	p.pageCache[defaultPath] = page
	return page, nil
}

// normalizePath converts URL path to page identifier
func (p *PageFactory) normalizePath(path string) string {
	trimmedPath := strings.TrimRight(path, "/")
	if trimmedPath == "" {
		return "/"
	}
	return strings.ToLower(trimmedPath)
}

// OnMount is called when the component is mounted, used to initialize shared data and load the initial page.
func (p *PageFactory) OnMount(ctx app.Context) {
	logger.Infof("PageFactory onMount called")

	// Initialize page cache
	if p.pageCache == nil {
		p.pageCache = make(map[string]zcomponents.PageInterface)
	}

	// Initialize layout once
	p.initializeLayout(ctx)

	// Load the initial page content
	p.loadPage(ctx)

	// invoke current page onMount
	p.currentPage.OnMount(ctx)
}

// OnNav is triggered when navigation occurs and loads the new page associated with the current URL path.
func (p *PageFactory) OnNav(ctx app.Context) {
	currentPath := ctx.Page().URL().Path
	logger.Infof("PageFactory OnNav called for path: %s", currentPath)

	// Load the new page (pages will handle their own layouts)
	if err := p.loadPage(ctx); err != nil {
		logger.Errorf("Error loading page during OnNav: %v", err)
		// Optionally set some error UI or fallback
		return
	}

	// invoke current page OnNav if loaded successfully
	if p.currentPage != nil {
		defer func() {
			if r := recover(); r != nil {
				logger.Errorf("Recovered panic in currentPage.OnNav: %v", r)
			}
		}()
		p.currentPage.OnNav(ctx)
	}
}

// Render renders the main page
func (p *PageFactory) Render() app.UI {
	if p.layout == nil {
		return app.Div().
			Class("loading").
			Text("Loading RISA Dashboard...")
	}
	return app.Div().Body(
		p.layout.Render(),
	)
}

// initializeLayout creates the layout once and sets up navigation handling
func (p *PageFactory) initializeLayout(ctx app.Context) {
	logger.Infof("initializing layout")

	// Initialize a Resources menu as collapsed by default to show toggle behavior
	p.resourcesMenuExpanded = false

	config := zcomponents.SimpleLayoutConfig{
		AppTitle:       "Risa Dashboard",
		ActiveMenuItem: "🏗️ Resources", // Set Resources as active menu item with collapsed indicator and icon
		MenuItems:      p.getDefaultMenuItems(),
		UserProfile:    p.getAppUserProfile(),
		LayoutConfig:   zcomponents.GetDefaultLayoutConfig(),
	}
	config.LayoutConfig.CollapsedLeftPane = p.globalSidebarCollapsed

	p.layout = zcomponents.SetupSimpleLayout(ctx, config)

	// Set Resources as the active menu item
	logger.Infof("setting up initial menu state with Resources as active item")
	zcomponents.UpdateActiveMenuItem(p.layout, "▶ 🏗️ Resources")

	// set callback to update global state when toggle is clicked
	p.layout.SetToggleCallback(func(collapsed bool) {
		logger.Infof("updating global sidebar state to collapsed=%v", collapsed)
		p.sidebarCollapsed = collapsed
	})
}

// loadPage handles the navigation to a specified page based on the current context and updates the current page state.
func (p *PageFactory) loadPage(ctx app.Context) error {
	currentPath := ctx.Page().URL().Path
	logger.Infof("🔄 LOAD: loading page for path: %s", currentPath)
	logger.Infof("🔄 LOAD: Current toggle state before load: %v", p.resourcesMenuExpanded)

	// Check if we're already on this page
	if p.currentPagePath == currentPath && p.currentPage != nil {
		logger.Debugf("🔄 LOAD: already on page %s, calling OnNav", currentPath)
		p.currentPage.OnNav(ctx)
		return nil
	}

	// get a page using factory (with caching)
	newPage, err := p.getPage(currentPath)
	if err != nil {
		logger.Errorf("Error creating page: %v", err)
		return err
	}
	if newPage == nil {
		logger.Errorf("Got nil page for path: %s", currentPath)
		return fmt.Errorf("page not found")
	}

	// update the current page state
	p.currentPage = newPage
	p.currentPageID = newPage.GetPageID()
	p.currentPagePath = currentPath

	pageTitle := newPage.GetPageTitle()
	logger.Infof("🔄 LOAD: loaded page: %s (%s) with title: '%s'", p.currentPageID, currentPath, pageTitle)
	logger.Infof("🔄 LOAD: Toggle state before layout update: %v", p.resourcesMenuExpanded)

	// Get page content and update the layout
	if p.layout != nil {
		zcomponents.UpdateLayoutContent(p.layout, newPage)

		// Ensure Resources menu is expanded when navigating to any AWS service page
		logger.Infof("🔄 LOAD: About to call expandResourcesMenuForPage")
		p.expandResourcesMenuForPage(pageTitle, ctx)
		logger.Infof("🔄 LOAD: Toggle state after expandResourcesMenuForPage: %v", p.resourcesMenuExpanded)

		// Refresh menu items to reflect current toggle state
		newMenuItems := p.getDefaultMenuItems()
		p.layout.SetMenuItems(newMenuItems)
		logger.Infof("🔄 LOAD: Refreshed menu items after page load, current state: %v, item count: %d",
			p.resourcesMenuExpanded, len(newMenuItems))

		// Update the active menu item with correct tree structure format
		activeMenuTitle := p.getTreeMenuTitle(pageTitle)

		logger.Infof("🔄 LOAD: updating active menu item to: '%s'", activeMenuTitle)
		zcomponents.UpdateActiveMenuItem(p.layout, activeMenuTitle)

		// Trigger re-render to update menu highlighting
		logger.Infof("🔄 LOAD: About to call ctx.Update()")
		ctx.Update()
		logger.Infof("🔄 LOAD: ctx.Update() completed")
	} else {
		logger.Warnf("Layout is nil, cannot update content")
	}
	p.updateFooter(ctx)
	return nil
}

// getTreeMenuTitle returns the correct menu title format for tree structure
func (p *PageFactory) getTreeMenuTitle(pageTitle string) string {
	if pageTitle == "Resources" {
		// For Resources page, use the correct expand/collapse indicator with icon
		if p.resourcesMenuExpanded {
			return "🏗️ Resources"
		} else {
			return "🏗️ Resources"
		}
	} else if pageTitle == "Help" {
		return "Help"
	} else {
		// For AWS service pages, use tab indentation with icons
		icon := p.getIconForPageTitle(pageTitle)
		return "\t" + icon + " " + pageTitle
	}
}

// updateFooter updates the footer content in the layout and triggers a UI rerender.
func (p *PageFactory) updateFooter(ctx app.Context) {
	if p.layout != nil {
		if setter, ok := interface{}(p.layout).(interface {
			SetFooterContent(ui app.UI)
		}); ok {
			// Removed getLastFetchText; you can set custom footer content here if needed
			setter.SetFooterContent(app.Div().Text(""))
		}
		ctx.Update() // trigger rerender
	}
}

// expandResourcesMenuForPage ensures Resources menu is expanded when navigating to AWS service pages
func (p *PageFactory) expandResourcesMenuForPage(pageTitle string, ctx app.Context) {
	// List of page titles that should cause a Resources menu to expand
	awsServicePages := []string{
		"EKS Clusters", "EC2 Instances", "CloudFormation Stacks",
		"DynamoDB Tables", "EC2 Images", "Classic LoadBalancers", "RDS Snapshots",
		"Elastic IP Address", "Target Groups", "NAT Gateway", "Volumes", "Snapshots",
	}

	// Check if current page is an AWS service page (excluding Resources itself)
	isAWSServicePage := false
	for _, servicePage := range awsServicePages {
		if pageTitle == servicePage {
			isAWSServicePage = true
			break
		}
	}

	// Auto-expand for AWS service pages if currently collapsed
	if isAWSServicePage && !p.resourcesMenuExpanded {
		logger.Infof("page '%s' is an AWS service page - expanding Resources menu", pageTitle)
		p.resourcesMenuExpanded = true

		// Refresh the menu structure
		if p.layout != nil {
			newMenuItems := p.getDefaultMenuItems()
			p.layout.SetMenuItems(newMenuItems)
		}
	}
	// For Resources page itself, maintain current toggle state
	// (don't force expansion or collapse - let user's last toggle action persist)
	if pageTitle == "Resources" {
		logger.Infof("On Resources page - maintaining current menu state: %v", p.resourcesMenuExpanded)
	}
}

// NewPageFactory creates a new page factory instance
func NewPageFactory() *PageFactory {
	factory := &PageFactory{
		pageCache:             make(map[string]zcomponents.PageInterface),
		resourcesMenuExpanded: false, // Start with Resources menu collapsed to show toggle behavior
	}
	return factory
}